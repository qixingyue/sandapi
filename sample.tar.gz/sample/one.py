#coding=utf-8

import handlers.Base

@handlers.Base.RestMethod
class one(handlers.Base.RestBaseHandler):

    __url__ = "/one"

    def get(self):
        self.echo_data("this is one volueme world.")


